using UnityEngine;

[CreateAssetMenu(menuName = "Game/MasterData/FireEffectColorData", fileName = "FireEffectColorData_New")]
public class FireEffectColorData : ScriptableObject
{
    [Tooltip("���̐F���A�ǂ�FireColor���w�肷��")]
    [SerializeField] private FireColor _color;
    [Tooltip("GradientEditor�ō����Gradient")]
    [SerializeField] private Gradient _gradient = new Gradient();

    public FireColor Color => _color;
    public Gradient Gradient => _gradient;
}
