using UnityEngine;

/// <summary>
/// �΂̐F(FireColor)���Ƃ�Effect�̐F�BFireManager��1�����󂯎��
/// Effect�{��(Prefab)�́A��Ԃ��Ƃ�FireStateData.EffectPrefab������
/// </summary>
[CreateAssetMenu(menuName = "Game/FireEffectCatalog", fileName = "FireEffectCatalog")]
public class FireEffectCatalog : ScriptableObject
{
    [Tooltip("FireColor���Ƃ̐F(FireColorData)")]
    [SerializeField] private FireEffectColorData[] _colors;

    public bool TryGetGradient(FireColor color, out Gradient gradient)
    {
        if (_colors != null)
        {
            for (int i = 0; i < _colors.Length; i++)
            {
                if (_colors[i] != null && _colors[i].Color == color)
                {
                    gradient = _colors[i].Gradient;
                    return true;
                }
            }
        }

        gradient = null;
        return false;
    }
}