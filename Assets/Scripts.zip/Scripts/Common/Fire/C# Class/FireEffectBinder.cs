//using UnityEngine;

//public class FireEffectBinder
//{
//    private readonly FireRegistry _registry;

//    public FireEffectBinder(FireRegistry registry)
//    {
//        _registry = registry;
//    }

//    //�i���Ȃǂ�State��Kind���ς�������ɌĂ�
//    public void Apply(FireColor color, FireStateData data)
//    {
//        if (_registry.TryGet(color, out FireController fireController))
//            fireController.ApplyEffect(data.FireKind);
//    }
//}
