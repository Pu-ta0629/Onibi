using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

[RequireComponent(typeof(SectorGraphic))]
public class RadialMenu : MonoBehaviour
{
    public enum LabelType { TextMeshPro, Image }

    private class Item
    {
        public string Label;
        public Sprite Icon;
        public Action OnSelected;
    }

    [Header("Design")]
    [Tooltip("���S�̌��̔��a(Canvas�P��)�B0�Ō��̂Ȃ��~�ɂȂ�")]
    [SerializeField, Range(0f, 500f)] private float _innerRadius = 50f;
    [Tooltip("�~�̊O���̔��a(Canvas�P��)")]
    [SerializeField, Range(10f, 1000f)] private float _outerRadius = 180f;
    [Tooltip("��`�ǂ����̌���(�x)")]
    [SerializeField, Range(0f, 30f)] private float _gapAngle = 3f;
    [SerializeField] private Color _normalColor;
    [SerializeField] private Color _highlightColor;

    [Header("Label")]
    [SerializeField] private LabelType _labelType = LabelType.TextMeshPro;
    [SerializeField] private TMP_FontAsset _fontAsset;
    [SerializeField, Range(8f, 100f)] private float _fontSize = 24f;
    [Tooltip("TextMeshPro�p�̕\���T�C�Y(Canvas�P��)")]
    [SerializeField] private Vector2 _labelSize = new Vector2(160f, 60f);
    [SerializeField, Range(8f, 300f)] private float _iconSize = 56f;

    [Header("ActiveMenu")]
    [Tooltip("���S�ɕ\������TextMeshPro/Image�̑傫��(Canvas�P��)�BInner Radius�̓����Ɏ��܂�傫���ɂ���")]
    [SerializeField, Range(8f, 300f)] private float _activeSize = 80f;

    private readonly List<Item> _items = new List<Item>();
    private readonly List<SectorGraphic> _sectors = new List<SectorGraphic>();
    private RectTransform _root;
    private RectTransform _canvasRect;
    private Camera _uiCamera;
    private GameObject _activeLabel;   // ���S�ɕ\�����Ă��郉�x��
    private int _selectedIndex = -1;   // ���}�E�X������Ă��鍀��
    private int _activeIndex = -1;     // ���S�ɕ\�����鍀�ځB-1�Ȃ�\���Ȃ�
    private bool _isOpen;
    private bool _ready;

    /// <summary>�J�����Ƃ��ɒʒm����(true�ŊJ�����Afalse�ŕ���)</summary>
    public event Action<bool> OnOpenChanged;
    public bool isOpen => _isOpen;

    #region Public
    /// <summary>���ڂ�ǉ�����</summary>
    /// <param name="label">TextMeshPro���[�h�ŕ\�����镶��</param>
    /// <param name="icon">Image���[�h�ŕ\������X�v���C�g</param>
    /// <param name="onSelected">�I�΂ꂽ���Ɏ��s����֐�</param>
    public void AddItem(string label, Sprite icon, Action onSelected)
    {
        _items.Add(new Item { Label = label, Icon = icon, OnSelected = onSelected });
        if (_ready) Build();
    }

    /// <summary>���S�ɕ\�����鍀�ڂ��O����w�肷��B-1�ŕ\���Ȃ�</summary>
    public void SetActiveItem(int index)
    {
        _activeIndex = (index >= 0 && index < _items.Count) ? index : -1;
        RefreshActiveLabel();
    }
    #endregion

    #region Unity
    private void Start()
    {
        var canvas = GetComponentInParent<Canvas>();
        if (canvas == null)
        {
            Debug.LogError("[RadialMenu] Canvas is Null!!");
            return;
        }

        _root = (RectTransform)transform;
        canvas = canvas.rootCanvas;
        _canvasRect = (RectTransform)canvas.transform;

        // Overlay��null�̂܂܁A����ȊO��Render Camera���g��
        if (canvas.renderMode != RenderMode.ScreenSpaceOverlay)
            _uiCamera = canvas.worldCamera != null ? canvas.worldCamera : Camera.main;

        Build();
        _ready = true;
    }

    private void Update()
    {
        var mouse = Mouse.current;
        if (!_ready || mouse == null) return;

        var right = mouse.rightButton;
        var pos = mouse.position.ReadValue();

        if (right.wasPressedThisFrame) Open(pos);
        if (!_isOpen) return;
        if (right.isPressed) UpdateSelection(pos);
        if (right.wasReleasedThisFrame) Close();
    }
    #endregion

    #region Build
    // �~�����ڐ��œ���������`����蒼��(�^�オ0�ԖځA���v���)
    private void Build()
    {
        foreach (var s in _sectors) Destroy(s.gameObject);
        _sectors.Clear();

        int count = _items.Count;
        float step = 360f / count;
        float gap = count > 1 ? _gapAngle : 0f;
        float labelRadius = (_innerRadius + _outerRadius) * 0.5f;

        for (int i = 0; i < count; i++)
        {
            float center = i * step;

            var go = new GameObject("Object_Item", typeof(RectTransform), typeof(SectorGraphic));
            go.transform.SetParent(_root, false);
            ((RectTransform)go.transform).sizeDelta = Vector2.one * _outerRadius * 2f;

            var sector = go.GetComponent<SectorGraphic>();
            sector.color = _normalColor;
            sector.raycastTarget = false;   // �}�E�X����͊p�x�Ŏ��O�v�Z����
            sector.Setup(_innerRadius, _outerRadius, center - step * 0.5f + gap * 0.5f, center + step * 0.5f - gap * 0.5f);
            _sectors.Add(sector);

            // ���x���͐�`�̒����ɒu��
            float rad = center * Mathf.Deg2Rad;
            var pos = new Vector2(Mathf.Sin(rad), Mathf.Cos(rad)) * labelRadius;
            CreateLabel(go.transform, _items[i], pos, _labelSize, _iconSize);
        }

        SetSectorsActive(_isOpen);
        Highlight(-1);
        RefreshActiveLabel();
    }

    // LabelType�ɉ����ĕ������A�C�R�������(�A�C�R�����ݒ�̍��ڂ͕����ő�p)
    private GameObject CreateLabel(Transform parent, Item item, Vector2 pos, Vector2 textSize, float iconSize)
    {
        var go = new GameObject("Object_Label", typeof(RectTransform));
        go.transform.SetParent(parent, false);
        var rect = (RectTransform)go.transform;
        rect.anchoredPosition = pos;

        if (_labelType == LabelType.Image && item.Icon != null)
        {
            rect.sizeDelta = Vector2.one * iconSize;
            var icon = go.AddComponent<Image>();
            icon.sprite = item.Icon;
            icon.preserveAspect = true;
            icon.raycastTarget = false;
        }
        else
        {
            rect.sizeDelta = textSize;
            var text = go.AddComponent<TextMeshProUGUI>();
            if (_fontAsset != null) text.font = _fontAsset;
            text.text = item.Label;
            text.fontSize = _fontSize;
            text.alignment = TextAlignmentOptions.Center;
            text.color = Color.white;
            text.raycastTarget = false;
        }
        return go;
    }

    // ���S�̃��x������蒼���B�J���Ă��āA���ڂ��I�΂�Ă���Ƃ������\������
    private void RefreshActiveLabel()
    {
        if (_activeLabel != null) Destroy(_activeLabel);   // �ォ����̂ŁA��`����O�ɕ\�������
        if (_isOpen && _activeIndex >= 0 && _activeIndex < _items.Count)
            _activeLabel = CreateLabel(_root, _items[_activeIndex], Vector2.zero, Vector2.one * _activeSize, _activeSize);
    }

    private void SetSectorsActive(bool active)
    {
        foreach (var s in _sectors) s.gameObject.SetActive(active);
    }
    #endregion

    #region OpenClose
    private void Open(Vector2 screenPos)
    {
        if (_items.Count == 0) return;

        _isOpen = true;
        OnOpenChanged?.Invoke(true);

        if (RectTransformUtility.ScreenPointToWorldPointInRectangle(_canvasRect, screenPos, _uiCamera, out var world))
            _root.position = world;

        SetSectorsActive(true);
        Highlight(-1);
        RefreshActiveLabel();
    }

    private void Close()
    {
        if (_selectedIndex >= 0)
        {
            // �o�^�ς݂̍��ڂ�������x�I�ԂƉ����A�ʂ̍��ڂ�I�ԂƐ؂�ւ�
            _activeIndex = (_selectedIndex == _activeIndex) ? -1 : _selectedIndex;
            _items[_selectedIndex].OnSelected?.Invoke();
        }

        _isOpen = false;
        _selectedIndex = -1;
        SetSectorsActive(false);
        RefreshActiveLabel();
        OnOpenChanged?.Invoke(false);
    }
    #endregion

    #region Selection
    // ���j���[���S���猩���}�E�X�̊p�x�őI������BInnerRadius�̓�����DeadZone(���I��)
    private void UpdateSelection(Vector2 screenPos)
    {
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(_root, screenPos, _uiCamera, out var delta)) return;

        int index = -1;
        if (delta.magnitude >= _innerRadius)
        {
            float angle = Mathf.Repeat(Mathf.Atan2(delta.x, delta.y) * Mathf.Rad2Deg, 360f);   // �^�オ0�x�A���v���
            index = Mathf.RoundToInt(angle / (360f / _items.Count)) % _items.Count;
        }

        if (index != _selectedIndex) Highlight(index);
    }

    private void Highlight(int index)
    {
        _selectedIndex = index;
        for (int i = 0; i < _sectors.Count; i++)
        {
            bool on = i == index;
            _sectors[i].color = on ? _highlightColor : _normalColor;
            _sectors[i].rectTransform.localScale = on ? Vector3.one * 1.1f : Vector3.one;
        }
    }
    #endregion
}

//using System.Collections.Generic;
//using TMPro;
//using UnityEngine;
//using UnityEngine.InputSystem;
//using UnityEngine.UI;

//[RequireComponent(typeof(SectorGraphic))]
//public class RadialMenu : MonoBehaviour
//{
//    public enum LabelType {TextMeshPro, Image}
//    private class Item
//    {
//        public string Label;
//        public Sprite Icon;
//        public System.Action OnSelected;
//    }

//    [Header("Design")]
//    [Tooltip("���S�̌��̔��a(Canvas�P��)�B0�Ō��̂Ȃ��~�ɂȂ�")]
//    [SerializeField, Range(0f, 500f)] private float _innerRadius = 50f;
//    [Tooltip("�~�̊O���̔��a(Canvas�P��)")]
//    [SerializeField, Range(10f, 1000f)] private float _outerRadius = 180f;
//    [Tooltip("��`�ǂ����̌���(�x)")]
//    [SerializeField, Range(0f, 30f)] private float _gapAngle = 3f;
//    [SerializeField] private Color _normalColor;
//    [SerializeField] private Color _highlightColor;

//    [Header("Label")]
//    [SerializeField] private LabelType _labelType = LabelType.TextMeshPro;
//    [SerializeField] private TMP_FontAsset _fontAsset;
//    [SerializeField, Range(8f, 100f)] private float _fontSize = 24f;
//    [Tooltip("TextMeshPro�p�̕\���T�C�Y(Canvas�P��)")]
//    [SerializeField] private Vector2 _labelSize = new Vector2(160f, 60f);
//    [SerializeField, Range(8f, 300f)] private float _iconSize = 56f;

//    [Header("ActiveMenu")]
//    [Tooltip("���S�ɕ\������TextMeshPro/Image�̑傫��(Canvas�P��)�BInner Radius�̓����Ɏ��܂�傫���ɂ���")]
//    [SerializeField, Range(8f, 300f)] private float _activeSize = 80f;

//    private readonly List<Item> _items = new List<Item>();
//    private readonly List<SectorGraphic> _itemSectors = new List<SectorGraphic>();
//    private RectTransform _root;
//    private RectTransform _canvasRect;
//    private Canvas _rootCanvas;
//    private Camera _uiCamera;
//    private int _selectedIndex = -1;   // ���}�E�X������Ă��鍀��
//    private int _activeIndex = -1;     // ���S(ActiveMenu)�ɕ\�����Ă��鍀�ځB-1�Ȃ�\���Ȃ�
//    private GameObject _activeMenuObject;
//    private TextMeshProUGUI _activeText;
//    private Image _activeIcon;
//    private bool _isOpen;
//    /// <summary><summart>�J�����Ƃ��ɒʒm����(true�ŊJ�����Afalse�ŕ���)</summart>summary></summary>
//    public event System.Action<bool> OnOpenChanged;
//    private bool _isInitialized;

//    public bool isOpen => _isOpen;

//    #region Initialize
//    //public void Initialize()
//    public void Start()
//    {
//        if (_isInitialized)
//        {
//            Debug.LogWarning("[RadialMenu] Initialize : Already Initialized!! ");
//            return;
//        }

//        _root = (RectTransform)transform;

//        var parentCanvas = GetComponentInParent<Canvas>();
//        if (parentCanvas == null)
//        {
//            Debug.LogError("[RadialMenu] Initialize : Canvas is Null!!! ");
//            return;
//        }

//        _rootCanvas = parentCanvas.rootCanvas;
//        _canvasRect = (RectTransform)_rootCanvas.transform;

//        // Overlay��null�̂܂܁AScreen Space - Camera��Render Camera���g��
//        if (_rootCanvas.renderMode != RenderMode.ScreenSpaceOverlay)
//        {
//            _uiCamera = _rootCanvas.worldCamera;
//            if (_uiCamera == null)
//            {
//                Debug.LogWarning("[RadialMenu] Initialize : Render Camera is Not Set!! Camera.main is used");
//                _uiCamera = Camera.main;
//            }
//        }

//        BuildItems();
//        BuildActiveMenu();   // ��`����ɍ���āA��O�ɕ\������
//        Close(false);
//        _isInitialized = true;
//    }
//    #endregion

//    #region ItemRegister;
//    /// <summary>Radial�̍��ڂ𑝂₹��֐�
//    /// <br/><param name="label">TextMeshPro���[�h�ŕ\�����镶��</param>
//    /// <br/><param name="icon">Image���[�h�ŕ\������X�v���C�g</param>
//    /// <br/><param name="onSelected">�I�΂ꂽ���Ɏ��s����֐�</param>
//    /// </summary>
//    public void AddItem(string label, Sprite icon, System.Action onSelected)
//    {
//        if (onSelected == null)
//        {
//            Debug.LogWarning($"[RadialMenu] AddItem : onSelected is Null!! Label = {label}");
//        }

//        _items.Add(
//            new Item
//            {
//                Label = label,
//                Icon = icon,
//                OnSelected = onSelected
//            }
//            );

//#if UNITY_EDITOR
//        Debug.Log($"[RadialMenu] AddItem : Label = {label}, _items.Count = {_items.Count}");
//#endif

//        if (_isInitialized) RebuildItems();
//    }
//    /// <summary>���S�ɕ\�����鍀�ڂ��O����w�肷��B-1�ŕ\���Ȃ�</summary>
//    public void SetActiveItem(int index)
//    {
//        _activeIndex = (index >= 0 && index < _items.Count) ? index : -1;
//        RefreshActiveMenu();
//    }
//    #endregion

//    #region UnityEvent
//    private void Update()
//    {
//        if (!_isInitialized) return;

//        var mouse = Mouse.current;
//        if (mouse == null) return;

//        var right = mouse.rightButton;

//        // click start
//        if (right.wasPressedThisFrame) Open(mouse.position.ReadValue());

//        if (!_isOpen) return;

//        // holdding
//        if (right.isPressed) UpdateSelection(mouse.position.ReadValue());

//        // click end
//        if (right.wasReleasedThisFrame) Close(true);
//    }
//    #endregion

//    #region Build
//    // �~�����ڐ��œ���������`�𐶐�����
//    private void BuildItems()
//    {
//        int count = _items.Count;//���ڐ�
//        if (count == 0) return;

//        float step = 360f / count;//������
//        float gap = count > 1 ? _gapAngle : 0f;//���ړ��m�̊Ԋu
//        float labelRadius = (_innerRadius + _outerRadius) * 0.5f;

//        for (int i = 0; i < count; i++)// �^�オ0�ԖځA���v���
//        {
//            float centerAngle = i * step;

//            // ���ږ{�́i��`�j
//            var itemObject = new GameObject("Object_Item", typeof(RectTransform), typeof(SectorGraphic));
//            itemObject.transform.SetParent(_root, false);
//            var itemRect = (RectTransform)itemObject.transform;
//            itemRect.anchoredPosition = Vector2.zero;
//            itemRect.sizeDelta = Vector2.one * _outerRadius * 2f;

//            var itemSector = itemObject.GetComponent<SectorGraphic>();
//            itemSector.color = _normalColor;
//            itemSector.raycastTarget = false;   // �}�E�X����͎��O�v�Z����̂ŕs�v
//            itemSector.Setup(_innerRadius, _outerRadius, centerAngle - step * 0.5f + gap * 0.5f, centerAngle + step * 0.5f - gap * 0.5f);
//            _itemSectors.Add(itemSector);

//            // ���x���͐�`�̒����ɒu��
//            float radian = centerAngle * Mathf.Deg2Rad;
//            Vector2 labelPosition = new Vector2(Mathf.Sin(radian), Mathf.Cos(radian)) * labelRadius;

//            // ���x���B�\�����@��LabelType�Ő؂�ւ���
//            switch (_labelType)
//            {
//                case LabelType.TextMeshPro:
//                    {
//                        CreateTextLabel(itemObject.transform, _items[i], labelPosition);
//                        break;
//                    }
//                case LabelType.Image:
//                    {
//                        CreateImageLabel(itemObject.transform, _items[i], labelPosition);
//                        break;
//                    }
//            }
//        }
//    }

//    // TextMeshPro���x���𐶐�
//    private void CreateTextLabel(Transform parent, Item item, Vector2 position)
//    {
//        var labelObject = new GameObject("Object_Label", typeof(RectTransform), typeof(TextMeshProUGUI));
//        labelObject.transform.SetParent(parent, false);
//        var labelRect = (RectTransform)labelObject.transform;
//        labelRect.sizeDelta = _labelSize;
//        labelRect.anchoredPosition = position;

//        var label = labelObject.GetComponent<TextMeshProUGUI>();
//        if (_fontAsset != null) label.font = _fontAsset;   //Font�K��
//        label.text = item.Label;                           //Text�K��
//        label.fontSize = _fontSize;                        //�T�C�Y�K��
//        label.alignment = TextAlignmentOptions.Center;
//        label.color = Color.white;
//        label.raycastTarget = false;
//    }

//    //Image���x������
//    private void CreateImageLabel(Transform parent, Item item, Vector2 position)
//    {
//        //�A�C�R�������ݒ�̍��ځiMenu�Ȃǁj�́A�����\������Ȃ��Ȃ�̂ŁA�����ő���ɕ\������
//        if (item.Icon == null)
//        {
//            CreateTextLabel(parent, item, position);
//            return;
//        }

//        var iconObject = new GameObject("Object_Icon", typeof(RectTransform), typeof(Image));
//        iconObject.transform.SetParent(parent, false);
//        var iconRect = (RectTransform)iconObject.transform;
//        iconRect.sizeDelta = Vector2.one * _iconSize;
//        iconRect.anchoredPosition = position;   //��`�̒����ɔz�u

//        var icon = iconObject.GetComponent<Image>();
//        icon.sprite = item.Icon;
//        icon.preserveAspect = true;
//        icon.raycastTarget = false;
//    }

//    // ���S(ActiveMenu)�̕\���p�I�u�W�F�N�g�𐶐�����B�\�����@��LabelType�ɍ��킹��
//    private void BuildActiveMenu()
//    {
//        switch (_labelType)
//        {
//            case LabelType.TextMeshPro:
//                {
//                    _activeMenuObject = new GameObject("Object_ActiveText", typeof(RectTransform), typeof(TextMeshProUGUI));
//                    _activeMenuObject.transform.SetParent(_root, false);
//                    var textRect = (RectTransform)_activeMenuObject.transform;
//                    textRect.sizeDelta = Vector2.one * _activeSize;
//                    textRect.anchoredPosition = Vector2.zero;

//                    _activeText = _activeMenuObject.GetComponent<TextMeshProUGUI>();
//                    if (_fontAsset != null) _activeText.font = _fontAsset;
//                    _activeText.fontSize = _fontSize;
//                    _activeText.alignment = TextAlignmentOptions.Center;
//                    _activeText.color = Color.white;
//                    _activeText.raycastTarget = false;
//                    break;
//                }
//            case LabelType.Image:
//                {
//                    _activeMenuObject = new GameObject("Object_ActiveIcon", typeof(RectTransform), typeof(Image));
//                    _activeMenuObject.transform.SetParent(_root, false);
//                    var iconRect = (RectTransform)_activeMenuObject.transform;
//                    iconRect.sizeDelta = Vector2.one * _activeSize;
//                    iconRect.anchoredPosition = Vector2.zero;

//                    _activeIcon = _activeMenuObject.GetComponent<Image>();
//                    _activeIcon.preserveAspect = true;
//                    _activeIcon.raycastTarget = false;
//                    break;
//                }
//        }
//    }

//    // ���S(ActiveMenu)�̓��e�ƕ\��/��\�����A�I�𒆂̍��ڂɍ��킹�čX�V����
//    private void RefreshActiveMenu()
//    {
//        if (_activeMenuObject == null) return;

//        bool hasActive = _activeIndex >= 0 && _activeIndex < _items.Count;

//        if (hasActive)
//        {
//            var item = _items[_activeIndex];
//            if (_activeText != null) _activeText.text = item.Label;
//            if (_activeIcon != null)
//            {
//                _activeIcon.sprite = item.Icon;
//                _activeIcon.enabled = item.Icon != null;
//            }
//        }

//        // �J���Ă���Ԃ����A�I�𒆂̍��ڂ����鎞�ɕ\������
//        _activeMenuObject.SetActive(_isOpen && hasActive);
//    }

//    // �����̍��ڂ�j�����č�蒼��
//    private void RebuildItems()
//    {
//        foreach (var itemSector in _itemSectors)
//        {
//            Destroy(itemSector.gameObject);
//        }
//        _itemSectors.Clear();

//        BuildItems();

//        // ��蒼������`����O�ɕ\������
//        if (_activeMenuObject != null) _activeMenuObject.transform.SetAsLastSibling();

//        _selectedIndex = -1;
//        SetActiveAll(_isOpen);   // �J���Ă���Œ��Ȃ�\�����ێ�����
//        Highlight(-1);
//        RefreshActiveMenu();
//    }
//    #endregion

//    #region OpenClose
//    private void Open(Vector2 mouseScreenPosition)
//    {
//        if (_items.Count == 0)
//        {
//            Debug.LogWarning("[RadialMenu] Open : Items is Empty!! ");
//            return;
//        }

//        _isOpen = true;
//        _selectedIndex = -1;   // �J��������͖��I��
//        OnOpenChanged?.Invoke(true);

//        // ��ʒ[�Ō����Ȃ��悤�ɒ��S��␳�iCanvas�P�� �� ��ʃs�N�Z���j
//        //float margin = _outerRadius * _rootCanvas.scaleFactor;
//        //mouseScreenPosition.x = Mathf.Clamp(mouseScreenPosition.x, margin, Screen.width - margin);
//        //mouseScreenPosition.y = Mathf.Clamp(mouseScreenPosition.y, margin, Screen.height - margin);

//        if (RectTransformUtility.ScreenPointToWorldPointInRectangle(_canvasRect, mouseScreenPosition, _uiCamera, out Vector3 worldPosition))
//        {
//            _root.position = worldPosition;
//        }
//        else
//        {
//            Debug.LogWarning("[RadialMenu] Open : Failed to Convert Mouse Position!! ");
//        }

//        SetActiveAll(true);
//        Highlight(-1);
//        RefreshActiveMenu();   // �o�^�ς݂̍��ڂ𒆐S�ɕ\��
//    }

//    private void Close(bool execute)
//    {
//        bool wasOpen = _isOpen;

//        if (execute && _selectedIndex >= 0 && _selectedIndex < _items.Count)
//        {
//            // �o�^�ς݂̍��ڂ�������x�I�ԂƉ����A�ʂ̍��ڂ�I�ԂƐ؂�ւ�
//            _activeIndex = (_selectedIndex == _activeIndex) ? -1 : _selectedIndex;

//#if UNITY_EDITOR
//            Debug.Log($"[RadialMenu] Close : _selectedIndex = {_selectedIndex}, _activeIndex = {_activeIndex}");
//#endif
//            _items[_selectedIndex].OnSelected?.Invoke();
//        }

//        _isOpen = false;
//        _selectedIndex = -1;
//        SetActiveAll(false);
//        RefreshActiveMenu();
//        if (wasOpen) OnOpenChanged?.Invoke(false);
//    }

//    private void SetActiveAll(bool active)
//    {
//        foreach (var itemSector in _itemSectors)
//        {
//            itemSector.gameObject.SetActive(active);
//        }
//    }
//    #endregion

//    #region Selection
//    // ���j���[���S���猩���}�E�X�̊p�x�ō��ڂ�I������i��`�̏�ɏ���Ă���K�v�͂Ȃ��j
//    // ���S�̌��iInnerRadius�̓����j��DeadZone�B�����Ƀ}�E�X������Ƃ��͉����I�����Ȃ�
//    private void UpdateSelection(Vector2 mouseScreenPosition)
//    {
//        int count = _items.Count;
//        if (count == 0) return;

//        // ���j���[���S����̑��Έʒu�iCanvas�P�ʁj
//        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(_root, mouseScreenPosition, _uiCamera, out Vector2 delta))
//        {
//            return;
//        }

//        int index = -1;   // DeadZone�̒��͖��I��
//        if (delta.magnitude >= _innerRadius)
//        {
//            // �^���0�x�A���v���ɑ�����p�x
//            float angle = Mathf.Atan2(delta.x, delta.y) * Mathf.Rad2Deg;
//            if (angle < 0f) angle += 360f;

//            index = Mathf.RoundToInt(angle / (360f / count)) % count;
//        }

//        // �I�����ς�����Ƃ������\�����X�V����
//        if (index != _selectedIndex) Highlight(index);
//    }

//    private void Highlight(int index)
//    {
//        _selectedIndex = index;
//        for (int i = 0; i < _itemSectors.Count; i++)
//        {
//            _itemSectors[i].color = (i == index) ? _highlightColor : _normalColor;
//            _itemSectors[i].rectTransform.localScale = (i == index) ? new Vector2(1.1f, 1.1f) : Vector2.one;
//        }
//    }
//    #endregion
//}