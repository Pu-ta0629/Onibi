using UnityEngine;


/// Stage�̐����E�i�s���Ǘ�����N���X
/// �����𒆌p���āA�i�s�͐�������f�[�^���󂯎��
/// </summary>
public class StageManager : MonoBehaviour
{
    [Header("Stage")]
    [Tooltip("��������Stage���i�[�ϐ� �eSpawner��StageContext�y���œn��")]
    [SerializeField] private StageData _stage;


    [Header("Generator")]
    [Tooltip("�n�`�̐������s��S��")]
    [SerializeField] private FieldSpawnManager _fieldSpawnManager;

    [Tooltip("Entity�̐������s��S��")]
    [SerializeField] private EntitySpawnManager _entitySpawnManager;

    // Stage�̐��������s���� Initialize�ŏ�����
    private StageGenerator _stageGenerator;

    private StageController _stageController;
    private LostChildController _lostChild;

    private StageContext _context;

    public StageContext Context => _context;

    #region Initialize

    public void Initialize(HitWorld world, LostChildController lostChild, Camera mainCamera)
    {
        if (world == null || lostChild == null || mainCamera == null || _fieldSpawnManager == null || _entitySpawnManager == null)
        {
            Debug.LogError("[StageGenerator] Initialize : Reference is Null!!!");
            return;
        }

#if UNITY_EDITOR
        // Stage���ݒ�ł��A�eSpawner�̏������͑�����
        if (_stage == null)
        {
            Debug.LogWarning("[StageGenerator] Initialize : Stage is not set. Scene field is used");
        }
#else
 // Stage���ݒ�̏ꍇ
        if(_stage == null)
        {
            Debug.LogWarning("[StageGenerator] Initialize : Stage is not set. Scene field is used");
            return;
        }
#endif
        _context = new StageContext(_stage, world, lostChild, mainCamera, transform);

        _lostChild = lostChild;

        _stageGenerator = new StageGenerator(world, mainCamera, _context, _fieldSpawnManager, _entitySpawnManager);

        _stageGenerator.Generate();
        CreateController();
    }
    #endregion

    #region UnityLifeCycle

    private void Update()
    {
        _stageController?.Tick();
    }

    private void OnDestroy()
    {
        if (_stageController != null)
        {
            _stageController.StageCleared -= HandleStageCleared;
        }
    }
    #endregion

    #region Private
    // �I�΂ꂽGoal��StageConroller�֓n���āA������n�߂�
    private void CreateController()
    {
        GoalPlacement goal = _fieldSpawnManager.SelectedGoal;
        if (goal == null)
        {
            Debug.LogWarning("[StageManager] CreateController : Goal is selected. Stage clear is not judged");
            return;
        }

        _stageController = new StageController(_lostChild, goal);
        _stageController.StageCleared += HandleStageCleared;
        _stageController.Begin();
    }

    private void HandleStageCleared()
    {
        // _lostChild.Freeze();
        // _entitySpawnManager.Stop();
    }
    #endregion

}
